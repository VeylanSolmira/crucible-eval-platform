# Veylan Solmira

[GitHub](https://github.com/VeylanSolmira) | [LinkedIn](https://www.linkedin.com/in/veylansolmira/) | [Email](mailto\:veylan@protonmail.com) | United States

## Summary

Platform engineer with 8+ years building scalable, secure infrastructure systems and leading cross-functional engineering teams. Currently conducting independent AI safety research focused on evaluation methods and deceptive alignment—directly relevant to METR's mission. Proven expertise in Kubernetes orchestration, Python backend development, AWS/GCP infrastructure, and translating researcher needs into robust technical solutions.

## Relevant Experience

**Independent Researcher – AI Safety & Alignment** | Remote | 2024–Present
*Focus: Evaluation frameworks, deceptive alignment detection, interpretability*

- Designing evaluation protocols for detecting deceptive behaviors in language models, exploring methods similar to METR's autonomous replication assessments
- Building Python-based testing frameworks for multi-agent alignment scenarios with containerized evaluation environments
- Actively studying interpretability techniques (Inspect, causal tracing, SAE Lens) and policy-relevant evaluation methods
- Contributing to AI safety hackathons focused on scalable oversight and collaborative evaluation systems

**Datonique** – Platform & Infrastructure Engineering | Remote | 2018–2024

**Consultant, SRE and AI Infrastructure** | 2023–2024
- Architected cloud-native evaluation infrastructure for early-stage LLM adoption, emphasizing isolation and reproducibility
- Designed monitoring and reliability frameworks for ML workloads with security-first approach

**Team Lead, Data and SRE Engineering** | 2021–2023
- Led platform engineering team building Kubernetes-based infrastructure supporting both internal tools and external client pipelines
- Implemented comprehensive observability stack (Prometheus, Grafana) for monitoring distributed systems
- Established SRE culture emphasizing reliability, incident response, and cross-team collaboration
- Mentored engineers on infrastructure best practices and reliability engineering principles

**Senior Data/SRE Engineer** | 2018–2021
- Built multi-cloud infrastructure (AWS/GCP) using Terraform with focus on security and isolation
- Designed and implemented CI/CD pipelines with GitHub Actions for automated testing and deployment
- Created data pipeline architecture with versioning and reproducibility for analytical workflows
- Implemented infrastructure security policies including network isolation and access controls

**Victorious** – Data Engineering Lead, SRE Team | Santa Monica, CA | 2017–2018
- Owned end-to-end data infrastructure supporting production reliability and real-time analytics
- Designed Python/Java pipelines with emphasis on fault tolerance and monitoring
- Built automated testing frameworks for data pipeline validation

**ZipRecruiter** – Data Engineer | Santa Monica, CA | 2015–2016
- Developed large-scale ETL pipelines using Spark for ML model training and evaluation
- Built internal APIs and tools supporting cross-functional teams and ML workflows
- Implemented data versioning and experiment tracking for reproducible analyses

## Technical Skills

**Platform & Infrastructure**
- Container Orchestration: Kubernetes (production experience), Docker, container security
- Cloud Platforms: AWS (EKS, IAM, VPC), GCP, multi-cloud architectures
- Infrastructure as Code: Terraform, CloudFormation, GitOps practices
- CI/CD: GitHub Actions, automated testing, deployment pipelines

**Development & Data Engineering**
- Languages: Python (expert), Java, Scala, Bash, basic JavaScript/TypeScript
- Data Processing: Spark, versioned pipelines, streaming architectures
- Databases: PostgreSQL, Redshift, distributed systems

**AI/ML Operations**
- Model evaluation frameworks, experiment tracking, reproducibility
- PyTorch, Huggingface, interpretability tools
- Security-focused ML infrastructure design

**Reliability & Security**
- Monitoring: Prometheus, Grafana, distributed tracing
- Security: Network policies, IAM, secrets management, audit logging
- Incident response, postmortems, SRE practices

## Education

**University of California, Los Angeles**
- B.S., Computer Science
- B.S., Computational & Systems Biology (Bioinformatics)
- B.S., Molecular, Cell, and Developmental Biology
- Minor in Statistics

## Additional Background

- Active AI safety researcher with focus on evaluation methods directly relevant to METR's work
- Former U.S. Marine Infantry – proven ability to execute under pressure and lead teams
- Strong written communication skills essential for technical documentation and cross-team collaboration

## References

- Murali Vasudevan — Founder and CEO, Datonique Inc.
- John King — SRE Manager, Victorious
- Andrew Parker — Former Director of Data Science, ZipRecruiter
- Prianna Ahsan — Software Engineer, Salesforce; former UCLA classmate