# Veylan Solmira

[GitHub](https://github.com/VeylanSolmira) | [LinkedIn](https://www.linkedin.com/in/veylansolmira/) | [Email](mailto\:veylan@protonmail.com) | United States



**Independent Researcher – AI Safety & Alignment***Focus: deceptive alignment, recursive reward shaping, interpretability*Remote / Self-directed | 2024–Present

- Alignment Research Prototypes
  - Developing theoretical framework for epistemically-updating, ecologically-grounded reward shaping under multi-objective RL
  - Contributed to hackathon projects focused on constitutional agent design and collaborative judgment scaling for multi-agent alignment
  - Developing *Gaia.Logos*, an RLAIF framework for guiding agent planning and goal formation within ecologically bounded value constraints
  - Exploring narrative formation from multimodal datasets, e.g. historiographical compression—historical event-space into competing explanatory summaries—and its relevance to propaganda detection and epistemic distortion
- Actively studying interpretability techniques (e.g., Inspect, causal tracing, SAE Lens) and policy-relevant evaluation methods (e.g., METR-style deception evals)

## Research Focus

AI alignment, deceptive cognition, scalable oversight, interpretability, epistemic legibility, recursive reward shaping, agent modeling, ecological and moral frameworks for AI value alignment, reorienting development trajectories from narrow profit optimization toward ecocentric and life-aligned systems

## Education

**University of California, Los Angeles**

- B.S., Computational & Systems Biology (Bioinformatics)
- B.S., Computer Science
- B.S., Molecular, Cell, and Developmental Biology
- Minor in Statistics

## Professional Experience

**Datonique** – Los Angeles, CA (Remote) | 2018–2024

**Consultant, SRE and AI Infrastructure** | 2023–2024

- Supported core SRE workflows including monitoring, reliability audits, and CI/CD restructuring during infrastructure transitions
- Advised on early-stage adoption of LLM-integrated tooling, data workflows, and reliability-oriented evaluation strategies within a small-scale organizational context

**Team Lead, Data and SRE Engineering** | 2021–2023

- Directed cross-functional engineering team responsible for CI/CD pipelines, observability, and incident response; emphasized reliability culture and dev mentorship
- Designed Kubernetes-based data staging infrastructure supporting internal analytics and external client pipelines

**Senior Data and SRE Engineer** | 2019–2021

- Built Terraform-automated infrastructure on AWS and GCP; integrated GitHub Actions for end-to-end deployment workflows
- Implemented SRE policy for scalability planning, emergency protocols, and data pipeline resiliency

**Senior Data Engineer** | 2018–2019

- Established enterprise-wide data governance and access controls; deployed secure, monitored Tableau analytics environments
- Designed Redshift-based data warehouse to serve analytical and operational reporting layers

**Victorious** – Santa Monica, CA | 2017–2018

**Data Engineering Lead on Site Reliability Engineering Team**

- Owned and operated the full data engineering infrastructure, aligning SRE, backend, and analytics teams to support production reliability and real-time insight generation
- Designed and deployed Python/Java pipelines that bridged experimental outputs and production reliability

**ZipRecruiter** – Santa Monica, CA | 2015–2016

**Data Engineer on Data Science Team**

- Led Spark-based ETL and NLP pipeline development for job classification and large-scale data analytics; served as core infrastructure lead within the team
- Built internal Scala APIs and supported dashboarding tools (Looker, Redshift), connecting analytics, engineering, and campaign managers for ML-adjacent decision systems that improved customer targeting and budget allocation

## Technical Skills

**AI Modeling & Evaluation**PyTorch, Huggingface, Scikit-learn, Inspect, SAE Lens, causal tracing, deception probes, RLAIF, multi-objective reward design

**Data Infrastructure & Reliability Engineering**Spark, Terraform, Docker, Kubernetes, GCP, AWS, CI/CD, observability, incident response, postmortems, cross-team reliability culture, infrastructure ownership

## Additional Background & Honors

- Former U.S. Marine Infantry; Highest ASVAB in battalion of 1,000+ Marines
- GRE: 169 verbal, 165 quantitative, 6.0 writing (99.984th percentile overall)

## References

- Andrew Parker — Former Director of Data Science, ZipRecruiter
- Prianna Ahsan — Software Enginee, Salesforce; former UCLA classmate
- Murali Vasudevan — Founder and CEO, Datonique Inc.
- John King — SRE Manager, Victorious
