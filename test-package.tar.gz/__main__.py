"""
Main entry point for the Crucible Evaluation Platform.
Allows running as: python -m crucible
"""

from app import main

if __name__ == "__main__":
    main()
