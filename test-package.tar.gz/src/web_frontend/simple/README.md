# Simple Frontend

This folder is reserved for simple frontend assets when the frontend is split into modules.

Future contents:
- `index.html` - Basic HTML template
- `style.css` - Minimal styling
- `app.js` - Vanilla JavaScript

Currently, all frontend implementations are in `../web_frontend.py`.
